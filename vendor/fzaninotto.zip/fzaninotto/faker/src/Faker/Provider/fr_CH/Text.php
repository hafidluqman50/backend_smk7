<?php

namespace Faker\Provider\fr_CH;

class Text extends \Faker\Provider\fr_FR\Text
{

}
